package com.example.kafkaapp.consumer;

import com.example.kafkaapp.model.User;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class UserConsumer {

    @KafkaListener(topics = "users-topic", groupId = "my-group")
    public void consumeUser(User user) {
        System.out.println("Consumed user: " + user.getName() + ", Age: " + user.getAge());
    }
}