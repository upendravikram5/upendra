package com.example.kafkaapp.controller;

import com.example.kafkaapp.model.User;
import com.example.kafkaapp.service.KafkaProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private KafkaProducerService kafkaProducerService;

    @PostMapping
    public String publishUser(@RequestBody User user) {
        kafkaProducerService.sendUser(user);
        return "Message published to Kafka!";
    }
}